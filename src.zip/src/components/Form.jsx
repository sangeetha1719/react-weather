import React from 'react'

const Form = ({ todo, setTodo }) => {
  return (
    //  Form that when submitted adds a new todo item
      <form>
        <label htmlFor="todo">Input Todo</label>
        <br />
        {/* The input tracks the value of the todo state variable, and the onChange function allows the user to type in data to update the todo state variable */}
        <input type="text" name="todo" id="todo" placeholder="Enter you todo..." value={todo} onChange={(e) => setTodo(e.target.value)} />
        <br />
        <button type="submit">Add Todo</button>
      </form>
  )
}

export default Form