import React from 'react'

const Todo = ({ title, completed=false }) => {
  return (
    <li>{title} is {completed.toString()}</li>
  )
}

export default Todo