import Todo from "./Todo";

// Giving todos prop default value of empty array to prevent errors in component
const Todos = ({ todos = [] }) => {
  return (
    // React Fragments use empty HTML brackets as syntax "<>" "</>" and are useful to group elements together without adding additional elements to the page
    <>
      <h2>Todo Items</h2>
      <ul>
        {/* Using the .map method to iterate and render each todo item on the screen */}
        {todos.map((todo) => (
          <Todo key={todo.id} title={todo.title} completed={todo.completed} />
        ))}
      </ul>
    </>
  )
}
export default Todos