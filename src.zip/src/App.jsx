// Example of how to import a module from a library such as React
import { useState, useEffect } from "react";
import Todos from "./components/Todos";
import Form from "./components/Form";

const App = () => {
  // Using the useState hook to manage the state of the todo input with an empty string as the initial value
  // setting the initial value of todo to an item stored in local storage called search, if search does not exist we set the initial value to an empty string
  const [todo, setTodo] = useState(localStorage.getItem("search") || "");
  // state to handle if the color scheme is dark mode or not
  const [darkMode, setDarkMode] = useState(false);
  // state to handle if data is being loaded
  const [loading, setLoading] = useState(true);
  // state to handle if an error occurs in the application
  const [error, setError] = useState(false);
  // state to track value of todos in an array
  const [todos, setTodos] = useState([]);

  // Function to use alert to display message to user
  const displayMessage = (message) => {
    alert(message);
  }
  // Best Example using todo in depedency array to track the value of todo and does not cause unnecessary useEffect calls
  useEffect(() => {
    localStorage.setItem("search", todo);
  }, [todo]);

  // use effect to fetch todos from remote API and handle updating the todos, loading, and error variables
  useEffect(() => {
    // async function to get todos from remote API
    async function getTodos() {
      try {
        // set loading to be true when first calling this function
        setLoading(true);
        // using fetch to grab the todos from the API
        const response = await fetch("https://jsonplaceholder.typicode.com/todos");
        // convert the response to json format and save in data variable
        const data = await response.json();
        // set todos to the data to be rendered in our application
        setTodos(data);
        // after the fetch request is successful we can set loading to false
        setLoading(false);
      } catch (error) {
        // if an error occurs we still want to set loading to false
        setLoading(false);
        // if error occurs we set error to true to display error message on screen
        setError(true);
        console.log(error);
      }
    }
    // after creating getTodos function I need to call it below this comment
    getTodos();
  }, []);
  return (
    // Using ternary operator to determine if the app should be in dark mode or not
    <div className={`app ${darkMode ? "dark-mode" : "light-mode"}`}>
      {/* When the button is clicked setDarkMode is used to toggle between true and false, prev references the current value of darkMode */}
      <button type="button" onClick={() => setDarkMode((prev) => !prev)}>
        {darkMode ? "Dark Mode" : "Light Mode"}
      </button>
      <br />
      {/* When the user clicks this button call the displayMessage function */}
      <button type="button" onClick={() => displayMessage('Hi')}>Alert Message</button>
      {/* When rendering Form component we must pass in todo and setTodo props */}
      <Form todo={todo} setTodo={setTodo} />
      {error && <p>Error occurred while fetching todos</p>}
      {/* If loading is true then we display a loading icon, if loading is false render the todos */}
      {loading ? (
        <p>Todos Loading...</p>
      ):(
        // When we render the Todos component we pass in the todos array to be rendered
        <Todos todos={todos} />
      )}
    </div>
  )
}

export default App